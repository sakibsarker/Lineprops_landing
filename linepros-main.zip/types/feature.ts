
export type Feature = {
    title:string
    Image:string
    GIF:string
    PreMatches:string[]
}